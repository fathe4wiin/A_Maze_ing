import sys
from mlx import Mlx
from .mlx_ui import Button, Label
from .cell import Cell
from .maze_solver import bfs
from .maze_gen import MazeGen
from .maze_algo import MazeAlgo
from .player import Player
from .stats import Stats

class MazeVisualizer:
    def __init__(self, maze, mlx=None, mlx_ptr=None, win=None, player_color=0x55FFFFFF, cell_color=0xFFFFFFFF, wall_color=0xFF000000, pattern_color=0xFFFFD700, config=None, menu=None):
        self.running = False
        self.menu = menu  # Reference to menu for switching back
        self.maze = maze
        self.height = config.HEIGHT
        self.width = config.WIDTH
        self.config = config
        self.start = config.ENTRY  # (x, y) tuple for start cell
        self.exit = config.EXIT    # (x, y) tuple for exit cell
        self.path = []      # List of cells in the solution path
        self.show_path = False  # Flag to control path visibility
        
        # Fixed window size, calculate tile size based on cells
        self.win_width = 1000
        self.win_height = 720
        self.tile_size = min(self.win_width // self.width, self.win_height // self.height)
        
        # Calculate offset to center the maze
        self.offset_x = (self.win_width - self.width * self.tile_size) // 2
        self.offset_y = (self.win_height - self.height * self.tile_size) // 2
        
        # Colors (from parameters)
        self.cell_color = cell_color
        self.wall_color = wall_color
        self.player_color = player_color
        self.background_color = 0xFF7D7D7D
        self.highlight_color = pattern_color

        if mlx:
            self.mlx = mlx
        else:
            self.mlx = Mlx()

        self.perfect = config.PERFECT
        if mlx_ptr:
            self.mlx_ptr = mlx_ptr
        else:
            self.mlx_ptr = self.mlx.mlx_init()
            
        if not self.mlx_ptr:
            print("Failed to initialize MLX")
            sys.exit(1)
        if win:
            self.win = win
        else:
            self.win = self.mlx.mlx_new_window(self.mlx_ptr, self.win_width, self.win_height, "Maze Visualizer")
        
        self.player = Player(self.mlx, self.mlx_ptr, self.win, self.start[0], self.start[1], self.cell_color, self.maze, self.tile_size, self.offset_x, self.offset_y, player_color=player_color, start=self.start, exit=self.exit)
        self.mlx.mlx_key_hook(self.win, self.key_hook, None)
        self.mlx.mlx_loop_hook(self.mlx_ptr, self.render_loop, None)
        self.mlx.mlx_mouse_hook(self.win, self.mouse_hook, None)
        self.mlx.mlx_hook(self.win, 33, 0, self._close_hook, None)

        self.stats = Stats()
        
        # Initialize UI buttons once
        self.buttons = []
        self.setup_ui()
        
        # Precompute static 42 pattern
        self.patt = config.pattern
        if self.patt:
            self._compute_42_pattern()
        else:
            self.text_cells = set()

        # Clear background
        self.color_change(0, 0)
        
        # Draw the maze
        self.draw_maze()

        

    def draw_start_exit(self):
        marker_size = max(4, self.tile_size // 4)
        if self.start:
            sx, sy = self.start
            cell_center_x = self.offset_x + sx * self.tile_size + self.tile_size // 2 - marker_size // 2
            cell_center_y = self.offset_y + sy * self.tile_size + self.tile_size // 2 - marker_size // 2
            self.draw_filled_rect(cell_center_x, cell_center_y, marker_size, marker_size, 0xFFFF0000)  # Red for start
        if self.exit:
            ex, ey = self.exit
            cell_center_x = self.offset_x + ex * self.tile_size + self.tile_size // 2 - marker_size // 2
            cell_center_y = self.offset_y + ey * self.tile_size + self.tile_size // 2 - marker_size // 2
            self.draw_filled_rect(cell_center_x, cell_center_y, marker_size, marker_size, 0xFF00FF00)  # Green for exit
    def draw_pixel(self, x, y, color):
        if 0 <= x < self.win_width and 0 <= y < self.win_height:
            self.mlx.mlx_pixel_put(self.mlx_ptr, self.win, x, y, color)

    def color_change(self, x, y):

        for x in range(self.win_width):
            for y in range (self.win_height):
                self.mlx.mlx_pixel_put(self.mlx_ptr, self.win, x, y, self.background_color)


    def draw_line(self, x1, y1, x2, y2, color):
        # Implementation of Bresenham's line algorithm
        dx = abs(x2 - x1)
        dy = abs(y2 - y1)
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        err = dx - dy

        while True:
            self.draw_pixel(x1, y1, color)
            if x1 == x2 and y1 == y2:
                break
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x1 += sx
            if e2 < dx:
                err += dx
                y1 += sy

    def draw_filled_rect(self, x, y, width, height, color):
        for i in range(x, x + width):
            for j in range(y, y + height):
                self.draw_pixel(i, j, color)

    def get_dark_color(self, color):
        """Return the lightened version of a color using simple ifs."""
        if color == 0xFF2196F3:
            return 0xFF90CAF9  # Blue lighter
        if color == 0xFFE53935:
            return 0xFFEF9A9A  # Red lighter
        if color == 0xFFFB8C00:
            return 0xFFFFCC80  # Orange lighter
        if color == 0xFF43A047:
            return 0xFFA5D6A7  # Green lighter
        if color == 0xFF8E24AA:
            return 0xFFCE93D8  # Purple lighter
        if color == 0xFF00BCD4:
            return 0xFF80DEEA  # Cyan lighter
        if color == 0xFFFF4081:
            return 0xFFFF80AB  # Pink lighter
        if color == 0xFFFFD700:
            return 0xFFFFE57F  # Gold lighter
        if color == 0xFF00FF00:
            return 0xFF90EE90  # Lime lighter
        if color == 0xFF87CEEB:
            return 0xFFB0E0E6  # Sky Blue lighter
        if color == 0xFF673AB7:
            return 0xFFB39DDB  # Deep Purple lighter
        if color == 0xFFFF9800:
            return 0xFFFFCC80  # Orange pattern lighter
        return 0xFFCFCFCF  # Default light gray

    def _compute_42_pattern(self):
        """Precompute the 42 pattern cells - called once."""
        four = [
            (0,0), (0,1), (0,2), # Left vertical
            (1,2),               # Middle horizontal
            (2,0), (2,1), (2,2), (2,3), (2,4) # Right vertical
        ]
        two = [
            (4,0), (5,0), (6,0), # Top horizontal
            (6,1),               # Top right
            (4,2), (5,2), (6,2), # Middle horizontal
            (4,3),               # Bottom left
            (4,4), (5,4), (6,4)  # Bottom horizontal
        ]
        offset_x = (self.width - 7) // 2
        offset_y = (self.height - 5) // 2
        self.text_cells = set((x + offset_x, y + offset_y) for x, y in four + two)

    def setup_ui(self):
        """Create UI buttons once - not every frame."""

        
        button_color = 0xFF272727
        text_color = 0xFFFFFFFF
        
        btn_regenerate = Button(
            self.mlx, self.mlx_ptr, self.win,
            x=1020, y=502,
            w=250, h=50,
            color=button_color,
            text="Reset & Regenerate",
            text_color=text_color,
            on_click=lambda: (self.player_reset(), self.score_clear())
        )
        
        btn_toggle_path = Button(
            self.mlx, self.mlx_ptr, self.win,
            x=1020, y=582,
            w=250, h=50,
            color=button_color,
            text="Toggle Path",
            text_color=text_color,
            on_click=lambda: self.solve()
        )
        
        btn_quit = Button(
            self.mlx, self.mlx_ptr, self.win,
            x=1045, y=662,
            w=200, h=50,
            color=button_color,
            text="Back to Menu",
            text_color=text_color,
            on_click=lambda: self._back_to_menu()
        )
        
        self.buttons = [btn_regenerate, btn_toggle_path, btn_quit]

        self.lbls = [
            Label(self.mlx, self.mlx_ptr, self.win, 1040, 12, "Mazes Solved:", 0xFF000000),
            Label(self.mlx, self.mlx_ptr, self.win, 1040, 42, "Moves:", 0xFF000000)
        ]

        for lbl in self.lbls:
            lbl.draw()
        
        self.mazes_score = Label(self.mlx, self.mlx_ptr, self.win, 1200, 12, f"{self.stats.mazes_solved}", 0xFF000000)
        self.mazes_score.draw()

        self.steps = Label(self.mlx, self.mlx_ptr, self.win, 1200, 42, f"{self.stats.steps}", 0xFF000000)
        self.steps.draw()

    def draw_maze(self):
        """Draw the maze - called when maze changes."""
        # Draw entire maze area with cell color and assign color to each cell
        for row in self.maze:
            for cell in row:
                x = self.offset_x + cell.x * self.tile_size
                y = self.offset_y + cell.y * self.tile_size
                
                if (cell.x, cell.y) in self.text_cells:
                    cell.color = self.highlight_color
                    cell.dark_color = self.get_dark_color(self.highlight_color)
                else:
                    cell.color = self.cell_color
                    cell.dark_color = self.get_dark_color(self.cell_color)
                cell.in_path = False  # Reset path flag
                
                self.draw_filled_rect(x, y, self.tile_size, self.tile_size, cell.color)

        # Draw walls on top
        for row in self.maze:
            for cell in row:
                x = self.offset_x + cell.x * self.tile_size
                y = self.offset_y + cell.y * self.tile_size
                
                if cell.walls['N']:
                    self.draw_line(x, y, x + self.tile_size, y, self.wall_color)
                if cell.walls['S']:
                    self.draw_line(x, y + self.tile_size, x + self.tile_size, y + self.tile_size, self.wall_color)
                if cell.walls['E']:
                    self.draw_line(x + self.tile_size, y, x + self.tile_size, y + self.tile_size, self.wall_color)
                if cell.walls['W']:
                    self.draw_line(x, y, x, y + self.tile_size, self.wall_color)

        self.draw_start_exit()

    def render_loop(self, param):
        if self.player.x == self.exit[0] and self.player.y == self.exit[1]:
            self.player_reset()
        # Draw existing buttons (don't recreate them)
        for btn in self.buttons:
            btn.draw()

        # Draw the path if visible
        if self.show_path:
            self.draw_path()

        # Draw the player
        self.player.draw()


        return 0

    def draw_path(self):
        """Draw the solution path by darkening the cells."""
        for cell in self.path:
            x = self.offset_x + cell.x * self.tile_size
            y = self.offset_y + cell.y * self.tile_size
            cell.in_path = True
            self.draw_filled_rect(x, y, self.tile_size, self.tile_size, cell.dark_color)
        # Redraw walls on path cells
        for cell in self.path:
            x = self.offset_x + cell.x * self.tile_size
            y = self.offset_y + cell.y * self.tile_size
            if cell.walls['N']:
                self.draw_line(x, y, x + self.tile_size, y, self.wall_color)
            if cell.walls['S']:
                self.draw_line(x, y + self.tile_size, x + self.tile_size, y + self.tile_size, self.wall_color)
            if cell.walls['E']:
                self.draw_line(x + self.tile_size, y, x + self.tile_size, y + self.tile_size, self.wall_color)
            if cell.walls['W']:
                self.draw_line(x, y, x, y + self.tile_size, self.wall_color)
        # Redraw start/exit markers
        self.draw_start_exit()

    def key_hook(self, keycode, param):
        w = 119
        a = 97
        s = 115
        d = 100
        esc = 65307

        if keycode == esc:
            # Go back to menu
            self._back_to_menu()
        elif keycode == w:
            if self.player.move("up"):
                self.stats.add_step()
                self.steps.update(0xFFD9D9D9, text=f"{self.stats.steps}")
        elif keycode == a:
            if self.player.move("left"):
                self.stats.add_step()
                self.steps.update(0xFFD9D9D9, text=f"{self.stats.steps}")
        elif keycode == s:
            if self.player.move("down"):
                self.stats.add_step()
                self.steps.update(0xFFD9D9D9, text=f"{self.stats.steps}")
        elif keycode == d:
            if self.player.move("right"):
                self.stats.add_step()
                self.steps.update(0xFFD9D9D9, text=f"{self.stats.steps}")
        return 0
    
    def _back_to_menu(self):
        """Go back to menu."""
        self.running = False
        if self.menu:
            self.menu.running = True
        self.mlx.mlx_loop_exit(self.mlx_ptr)

    def mouse_hook(self, button, x, y, param):
        if button == 1:  # Left click
            for btn in self.buttons:
                btn.handle_click(x, y)
        return 0

    def close_window(self):
        self.running = False
        self.mlx.mlx_loop_exit(self.mlx_ptr)
        return 0
    
    def _close_hook(self, _):
        """Window close event handler (event 33) - quits everything."""
        self.running = False
        if self.menu:
            self.menu.running = False
        self.mlx.mlx_loop_exit(self.mlx_ptr)
        return 0

    def _setup_hooks(self):
        """Set up input hooks for the visualizer."""
        self.mlx.mlx_key_hook(self.win, self.key_hook, None)
        self.mlx.mlx_loop_hook(self.mlx_ptr, self.render_loop, None)
        self.mlx.mlx_mouse_hook(self.win, self.mouse_hook, None)
        self.mlx.mlx_hook(self.win, 33, 0, self._close_hook, None)

    def run(self):
        self.running = True
        # Re-register hooks (in case menu changed them)
        self._setup_hooks()
        # Draw the maze
        self.draw_maze()
        self.setup_ui()
        self.mlx.mlx_loop(self.mlx_ptr)
    
    def solve(self):
        if not self.start or not self.exit:
            return
        
        if self.show_path:
            # Toggle path off - reset in_path flags and redraw maze
            for cell in self.path:
                cell.in_path = False
            self.show_path = False
            self.draw_maze()
            return
        
        # Calculate and show path
        start_cell = self.maze[self.start[1]][self.start[0]]
        exit_cell = self.maze[self.exit[1]][self.exit[0]]
        self.path = bfs(self.maze, start_cell, exit_cell)
        self.show_path = True

    def regen(self):
        """Regenerate the maze with a new random layout."""
        maze_gen = MazeGen()
        layout = maze_gen.create_cell_layout(self.width, self.height)
        self.maze = maze_gen.generate_maze(layout, self.config)
        self.path = []
        self.show_path = False
        # Redraw the maze
        self.color_change(0, 0)
        self.draw_maze()
        # Redraw start/exit markers
        marker_size = max(4, self.tile_size // 4)
        if self.start:
            sx, sy = self.start
            cell_center_x = self.offset_x + sx * self.tile_size + self.tile_size // 2 - marker_size // 2
            cell_center_y = self.offset_y + sy * self.tile_size + self.tile_size // 2 - marker_size // 2
            self.draw_filled_rect(cell_center_x, cell_center_y, marker_size, marker_size, 0xFFFF0000)
        if self.exit:
            ex, ey = self.exit
            cell_center_x = self.offset_x + ex * self.tile_size + self.tile_size // 2 - marker_size // 2
            cell_center_y = self.offset_y + ey * self.tile_size + self.tile_size // 2 - marker_size // 2
            self.draw_filled_rect(cell_center_x, cell_center_y, marker_size, marker_size, 0xFF00FF00)
        self.player.x = self.start[0]
        self.player.y = self.start[1]
        self.player.maze = self.maze

    def player_reset(self):
        self.regen()
        self.stats.add_maze()
        self.mazes_score.update(0xFFD9D9D9, text=f"{self.stats.mazes_solved}")
        self.steps.update(0xFFD9D9D9, text=f"{self.stats.steps}")
        self.steps.draw()
        self.mazes_score.draw()

    def score_clear(self):
        self.stats.mazes_solved = 0
        self.stats.steps = 0
        self.mazes_score.update(0xFFD9D9D9, f"{self.stats.mazes_solved}")
        self.steps.update(0xFFD9D9D9, f"{self.stats.steps}")


